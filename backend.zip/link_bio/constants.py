# Cabecera
GITHUB_URL = "https://github.com/JsMelix"
TWITTER_X_URL = "https://twitter.com/CarpioWeen1"
INSTAGRAM_URL = "https://instagram.com/thesebastianxeii"
TIKTOK_URL = "https://tiktok.com/@sebastiangamerxeii"
SPOTIFY_URL = "https://open.spotify.com/show/0m5roRLD2lRCFXc2bBnrdc"
LINKEDIN_URL = "https://linkedin.com/in/sebastianmelo03/"

# Comunidad
TWITCH_URL = "https://www.infobae.com/colombia/2023/07/02/mas-de-500-jovenes-colombianos-se-graduaron-en-inteligencia-artificial-y-programacion/"
YOUTUBE_URL = "https://educonrosario.evolutool.com/index.php/6fe238abab086f347e5f52ade5889a36/8c787fa03757e6a235070c267cbd6989?fbclid=IwAR2cY24QYGbR9G2u6aWBgouLZOh4aMrHu9r_Vyu0O1Y_I0324ogbsx9ojzA"
YOUTUBE_SECONDARY_URL = "https://youtube.com/@mouredevtv"
DISCORD_URL = "https://es.linkedin.com/posts/cristianadan_ganador-del-open-ai-chat-gpt-hackathon-activity-7081519456786472960-Prhg?utm_source=li_share&utm_content=feedcontent&utm_medium=g_dt_web&utm_campaign=copy"
CODE_CHALLENGES_URL = "https://twitter.com/PyLatam/status/1695840230417301783"

# Recursos y más
BOOK_URL = "https://mouredev.com/libro-git"
BOOKS_URL = "https://amazon.es/shop/mouredev/list/2ZIHJJFJ9AVZ3"
SETUP_URL = "https://mouredev.com/setup"
MOUREDEV_URL = "https://mouredev.com"
COFFEE_URL = "https://buymeacoffee.com/mouredev"

# Contacto
MYPUBLICINBOX_URL = "https://mypublicinbox.com/mouredev"
EMAIL = "braismoure@mouredev.com"

# Sponsors
ELGATO_URL = "https://reflex.dev"
MVP_URL = "https://www.python.org"
